<?php
/**
 * Visforms
 *
 * @author       Ingmar Vack
 * @package      Joomla.Administrator
 * @subpackage   com_visforms
 * @link         http://www.vi-solutions.de
 * @license      GNU General Public License version 2 or later; see license.txt
 * @copyright    2018 vi-solutions
 * @since        Joomla 3.0.0
 */

defined('_JEXEC') or die('Restricted access');
?>
<div class="div_ajax-call-wait div_ajax-call-wait_<?php echo $displayData ?>"><span class="icon_ajax-call-wait icon_ajax-call-wait_<?php echo $displayData ?>"></span></div>