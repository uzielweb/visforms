ALTER TABLE `#__visforms` ADD COLUMN `viscaptchaoptions` text;
ALTER TABLE `#__visforms` ADD COLUMN `emailresultsettings` text;
ALTER TABLE `#__visforms` ADD COLUMN `emailresulttext` longtext;