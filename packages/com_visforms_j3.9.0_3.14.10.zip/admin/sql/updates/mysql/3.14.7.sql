ALTER TABLE `#__visfields` ADD COLUMN `decodeqpvalue` tinyint(1) NOT NULL default 0;
ALTER TABLE `#__visfields` ADD COLUMN `encoderedirectvalue` tinyint(1) NOT NULL default 0;