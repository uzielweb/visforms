ALTER TABLE `#__visforms` ADD COLUMN `editemailresultsettings` longtext;
ALTER TABLE `#__visforms` ADD COLUMN `editemailreceiptsettings` longtext;