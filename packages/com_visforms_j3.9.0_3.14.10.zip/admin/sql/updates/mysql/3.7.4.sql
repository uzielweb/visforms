ALTER TABLE `#__visforms` MODIFY `published` tinyint(4) NOT NULL default 0;
ALTER TABLE `#__visfields` MODIFY `published` tinyint(4) NOT NULL default 0;